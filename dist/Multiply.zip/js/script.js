/**
 * Multiply
 * @author ArtHouse379
 * version v1.0
 * 
 */


; function Multiply(options) {
    options = {
        elem: options.elem,
        count: options.count || 10,
        title: options.title || 'Table',
        captionAlign: options.captionAlign || 'center',
        captionColor: options.captionColor || '#000',
    }


    function init() {
        
        let content = `
        <table class="table-multiply">
            <caption style="
            text-align: ${options.captionAlign}; 
            color: ${options.captionColor}">${options.title}
            </caption>`;

        for (let i = 0; i < options.count; i++) {
            content += '<tr>';

            for (let j = 0; j < options.count; j++) {
                content += `<td>${i*j}</td>`;
            }

            content += '</tr>';
        }
        content += `</table>`;
        options.elem.innerHTML = content;
    }


    init();
};






// вызов виджета
let multiply = new Multiply({
    // элемент, в который будет вливаться виджет
    elem: document.querySelector('#wrap-multiply'),
    count: 3,
    title: 'Считаем до трех',
    captionAlign: 'left',
    captionColor: '#38C864',
});

// вызов виджета
let multiply2 = new Multiply({
    // элемент, в который будет вливаться виджет
    elem: document.querySelector('#table-multiply'),
    captionSize: '2em',
});


// вызов виджета
let multiply3 = new Multiply({
    // элемент, в который будет вливаться виджет
    elem: document.querySelector('.table'),
    count: 5,
    title: 'О! До пяти',
    captionAlign: 'right',
    captionColor: 'red',
});